class ErrorMain{
	public static void main(String args[]){
		int x[]={1,2,3};
		try{
			for(int i=0;i<4;i++)
				System.out.println(x[i]);
		}
		catch(Exception e){
				System.out.println("�����߻� -��-");
		}
		System.out.println("�Ϸ� ^��^/");
	}
}