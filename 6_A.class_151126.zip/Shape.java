class Shape {
	int x,y;
	void print (){
		System.out.println("Shape");
	}
}
class Rectangle extends Shape {
	int z ;
	void print (){
		System.out.println("Rect");
	}
}
class ShapeMain{
	public static void main(String args[]){
	Rectangle r =new Rectangle();
	Rectangle r1 =new Rectangle();
	Shape s =new Shape();
	r.print();
	s.print();
	s=r;
	s.print();
		
	}
}