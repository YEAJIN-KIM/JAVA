abstract class Shapes {
	final double PI=3.141592;
	abstract double getArea();
}

abstract class TwoDimshape extends Shapes {
}
abstract class ThreeDimshape extends Shapes {
	abstract double getVolumn();
	double getArea(){return 0;};//���� �ߴϱ� 
}

class Circle extends TwoDimshape{
	int r;
	double getArea(){
		return PI*r*r;
	}
}
class Rectangle extends TwoDimshape{
	double w,h;
	double getArea(){
		return w*h;
	}
}
class Triangle extends TwoDimshape{
	double w,h;
	double getArea(){
		return w*h*0.5;
	}
}
class Sphere extends ThreeDimshape{
	int r;
	double getVolumn(){
		return 4/3*PI*r*r*r;
	}
}
class Cube extends ThreeDimshape{
	int w,h,l;
	double getVolumn(){
		return w*h*l;
	}
}
class Cylinder extends ThreeDimshape{
	int r,h;
	double getVolumn(){
		return PI*r*h;
	}
}


class ShapesMain{
	public static void main(String args[]){
		Circle c=new Circle();
		c.r=10;
		System.out.println(c.getArea());

		Sphere s =new Sphere();
		s.r=10;
		System.out.println(s.getVolumn());

		Shapes sh;
		sh=c;
		System.out.println(sh.getArea());
		sh=s;
		Sphere s2 =new Sphere();
		s2=(Sphere) sh;
		System.out.println(s2.getVolumn());
	}
}