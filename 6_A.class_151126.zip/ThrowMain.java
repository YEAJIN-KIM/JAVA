class ThrowMain {
	public static void main(String args[]){
		ThrowMain tm = new ThrowMain();
		try{
			tm.print("�ȳ�!");
		}
		catch(Exception e){
			System.out.println("����");
		}
	}

	 void print(String str) throws Exception{
		System.out.println(str);
	}
}