class SplitMain {
	public static void main(String args[]){
		String str ="Kim:Lee:Park:Hong:Kang,1:2:3:4:5";

		String x[]=str.split(",");	//�̸�(x[0])�� �й�(x[1])�и�

		String name[]=x[0].split(":");	//�̸� �и�
		String num[]=x[1].split(":");	// �й� �и�

		System.out.println(name.length);
		System.out.println(num.length);

		for(int i=0;i<name.length;i++)
			System.out.println(name[i]);
		for(int i=0;i<num.length;i++)
			System.out.println(num[i]);
			
	}
}


