class Student{
	String name;
	String num;
	Stirng addr;
	Student(String x,String y,String z){
		name=x;
		num=y;
		addr=z;
	}
	student (String x){
		String a[]=x.split(",");
		name=a[0];
		num=a[1];
		addr=a[2];
	}
	void printx(){
		System.out.println("�й�:"+num+"�̸�:"+name);
	}
}
class SplitMains {
	public static void main(String args[]){

		String str ="Kim,1,Seoul:Lee,2,Ansan:Park,3,Sanbon:Hong,4,Anyang:Kang,5,Incheon";
		String x[]=str.split(":");
		Student st[]=new Student[x.length];

		for(int i=0;i<x.length;i++){
			st[i]=new Student(x[i]);
		}

		for(int i=0;i<x.length;i++)
			st[i].printx();
		
			
	}
}