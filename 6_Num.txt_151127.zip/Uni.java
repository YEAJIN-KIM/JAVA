Student(String x) {
	


MStudent

DStudent 








class Uni{
	public static void main(String args[]){
				
		try{
			int c;
			String s=new String ();
			while((c=in.read())!=-1) 
				s=s+(char)c;
			in.close();
				System.out.println(s);
			
			}
				FileWriter out = new FileWriter("Student.txt");
				out.write(); 
				out.close();			

		}catch (FileNotFoundException fe){
			System.out.println("������ ����!");
		}catch (Exception e){
			System.out.println("������ �������� �ʾƵ�!");
		}

	
	}
}