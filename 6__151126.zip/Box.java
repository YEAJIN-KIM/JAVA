class Box {
	int length;
	int width;
	int height;
	
	Box() { 
	
	}

	Box(int l, int w, int h){
		length = l;
		width = w;
		heigh = h;
	}
	void setLength(int l) {
		length=l;
	void setWidth(int w) {
		 width=w;
	}
	void setHeight(int h) {
		height=h;
	}
	int getVolumn() {
		return  length*width*height; // return l*w*h (x)
	}			
}
class ColorBox extends Box {
	String color;
	
	ColorBox(int l, int w, int h, String c){
		super(l,w,h);
		color=c;
	}
	void setColor(String c){
		color=c;
	}
}
class ColorBoxTest {
	public static void main (String [] args){
		ColorBox b1 = new ColorBox(1,2,3,"����");
		b1.setColor("�Ķ�"); //����->�Ķ� ���ٲ�
		System out.println(b1.getVolume()) ;
}