class Cal{
	int square(int x){
		return x*x;
	}
	int max(int a, int b){
		if(a>b)
			return a;
		else 
			return b;		
	}
	int min(int c , int d){
		if(c<d)
			return c;
		else
			return d;
	}
	void add(int e, int f){
		System.out.println(e+f);

	}
}
