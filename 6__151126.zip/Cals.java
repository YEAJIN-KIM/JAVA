 abstract class Cals{
	int a,b;
	 abstract void answer(){};
}
