class Cat{
	int cAge;
	String cName;
	Cat() {
	}
	Cat(int a,String n){
		cAge=a;
		cName=n;
	}
	Cat (String n, int a){
		cAge=a;
		cName=n;
	}
	int getAge() {
		System.out.println("���̴�:"+ cAge);
		return cAge;
	}
}

class CatMain {
	public static void main(String args[]) {
		Cat ca1 = new Cat("������",3);
		System.out.println(ca1.getAge());
	}
}