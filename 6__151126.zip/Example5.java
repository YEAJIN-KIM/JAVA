import java.util.Scanner;
class Example5 {
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
			System.out.println("�� ���� �Է��Ͻʽÿ�");
			int a,b= scan.nextInt();
			int i;
			int c=0;
			if(a>=b){
				for(i=b;i<a+1;i++){
				c=c+i;
				
					}
		
			if(b>=a){
				for(i=a;i<b+1;i++){
				c=c+i;
				}
			}
		}
			System.out.println(c);	
	}
}