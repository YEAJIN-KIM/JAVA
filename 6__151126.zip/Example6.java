import java.util.Scanner;
class Example6 {
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
		System.out.println("���ڸ� �Է��Ͻʽÿ�");
		int a= scan.nextInt();
		int b=1;
		int i;
		for(i=1;i<=a;i++){
			b=b*i;
		}
		System.out.println(b);
	}
}
			