import java.util.Scanner;
class Example7 {
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);
		System.out.println("�����ڸ� �Է��ϼ���");
		String a=scan.nextLine();
		System.out.println("�� ���� �Է��ϼ���.");
		
		int b=scan.nextInt();
		int c=scan.nextInt();

		if (a.equals("+"))
			System.out.println(b+c);

		else if (a.equals("-"))
			System.out.println(b-c);

		else if (a.equals("*"))
			System.out.println(b*c);

		else if (a.equals("/"))
			System.out.println(b/c);

		else 
			System.out.println(b%c);
			
			
			
		
	}
}