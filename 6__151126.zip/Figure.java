class Figure{
	int w;
	int h;
	
	void setValue(int a, int b){
		w=a;
		h=b;
	}
	abstract int getArea();
}

class Rectangle extends Figure{
	int getAtrea(){
		return w*h;
	}
}

class Triangle extends Figure{
	int getAtrea(){
		return w*h*0.5;
	}
}
class Square extends Rectangle{
	 void setValue(int a){
		w=a;
		h=a;
	}
	
}