class Human {
	String name;
	int age;
	
	Human(String n, int a){
		name=n;
		age=a;
	}
	String toStr() {
		return age+"/"+name; // ����/�̸�

	}
}
class HumanTest {
	public static void main(String args[]) {
		Human h1=new Human("ȫ�浿",20);
		System.out.println(h1.toStr());
	
	}
}

Class Student extends Human {
	String major;

	Student (String n, int a,String m){
		super()
	}
}