public interface Movable {
	public abstract void move (int dx, int dy);
}

class Point implements Movable {
	int x , y;
	public void move(int dx .int dy){
		x= x+dx ;
		y= y+dy ;
	}
}