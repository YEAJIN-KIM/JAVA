class Multi {
	int y;
	int multi(int a,int b) {
		y=a*b;
		return y;
	}
	void multiPrint(int a,int b) {
		System.out.println(a+"*"+b+"="+multi(a,b));
	}
	void multiNinePrint(int a){
		for(int i=1;i<10;i++)
			multiPrint(a,i);
	}
}

class MultiMain{
	public static void main(String args[]){
		Multi mu=new Multi();
		//System.out.println(mu.multi(3,5));
		for(int i=1;i<10;i++)
		mu.multiNinePrint(i);

	}
}
