class Rect{
	private int length ;
	private int width;

	Rect(int l,int w) {
		length=l;
		width=w;
	}
	void setLength(int x) { 
		length=x ;
	}
	void setWidth(int y) {
		width=y ;
	}
	int getLength() { 
		return length ;
	}
	int getWidth() {
		return width ;
	}
	int getArea() {
		return width*length ;
	}
}

	

class ColorRect extends Rect{
	private String color;

	ColorRect(int a,int b,String c){
		super(a,b);//length=a; width=b;
		color=c; //����
	}
}
	